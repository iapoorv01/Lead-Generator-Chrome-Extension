console.log('Content script injected successfully');

// Cache for scraped data
let cachedProfileData = null;

// Function to check if we're on a LinkedIn profile page
function isLinkedInProfilePage() {
  return window.location.href.match(/^https?:\/\/(www\.)?linkedin\.com\/in\/[^/?#]+/);
}

// Function to notify background script about page type
function notifyPageType() {
  chrome.runtime.sendMessage({
    action: 'pageTypeChanged',
    isProfilePage: isLinkedInProfilePage()
  });
}

// Call notifyPageType when the page loads
notifyPageType();

// Also listen for URL changes (for single-page applications)
let lastUrl = location.href;
new MutationObserver(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    notifyPageType();
  }
}).observe(document, { subtree: true, childList: true });

// Click "Show more" button if it exists
function tryLoadFullExperience() {
  try {
    const showMoreButton = document.querySelector('button[aria-label*="Show more experience"], button[aria-label*="more experience"], .pvs-navigation__see-more, .artdeco-button--tertiary');
    if (showMoreButton) {
      console.log('Found Show more button:', showMoreButton.outerHTML);
      showMoreButton.click();
      console.log('Clicked Show more button');
      // Wait 1 second for content to load
      const startWait = Date.now();
      while (Date.now() - startWait < 1000) {
        // Busy wait
      }
      return true;
    }
    console.log('No Show more button found');
    return false;
  } catch (error) {
    console.error('Error in tryLoadFullExperience:', error);
    return false;
  }
}

// Function to wait for element to be present
function waitForElement(selector, timeout = 5000) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    const checkElement = () => {
      const element = document.querySelector(selector);
      if (element) {
        resolve(element);
        return;
      }
      if (Date.now() - startTime >= timeout) {
        resolve(null);
        return;
      }
      setTimeout(checkElement, 100);
    };
    checkElement();
  });
}

// Scrape LinkedIn profile data
function scrapeLinkedInProfile() {
  try {
    console.log('Scraping LinkedIn profile');
    let name = cachedProfileData?.name || '';
    let position = cachedProfileData?.position || '';
    let company = cachedProfileData?.company || '';
    let email = '';
    let phone = '';
    let website = '';
    let linkedin_url = cachedProfileData?.linkedin_url || '';
    let companies = cachedProfileData?.companies || [];

    // Check if on contact info overlay page
    if (window.location.href.includes('/overlay/contact-info/')) {
      console.log('On contact info overlay page');
      console.log('Using cached profile data:', cachedProfileData);

      // Wait for contact items to load with increased timeout (20 seconds)
      return waitForElement('.pv-contact-info__contact-type', 20000).then(async (contactItems) => {
        if (contactItems) {
          // Wait an additional second for content to fully load
          await new Promise(resolve => setTimeout(resolve, 1000));
          
          const items = document.querySelectorAll('.pv-contact-info__contact-type');
          console.log('Contact items found:', items.length);
          console.log('Full contact info section HTML:', document.querySelector('.pv-contact-info__content')?.outerHTML);
          
          // Try to get name from contact info page if not found earlier
          if (name === 'Unknown Name') {
            const contactNameElement = document.querySelector('.pv-contact-info__profile-title, .artdeco-entity-lockup__title');
            if (contactNameElement) {
              name = contactNameElement.textContent.trim();
              console.log('Found name on contact info page:', name);
            }
          }
          
          // Process each contact item
          for (const item of items) {
            const header = item.querySelector('.pv-contact-info__header')?.textContent.trim().toLowerCase();
            console.log('Processing contact item:', item.outerHTML);
            console.log('Header found:', header);
            
            if (header) {
              // Email extraction
              if (header.includes('email')) {
                console.log('Found email section:', item.outerHTML);
                const emailLink = item.querySelector('a[href^="mailto:"]');
                if (emailLink) {
                  email = emailLink.href.replace('mailto:', '').trim();
                  console.log('Extracted email from link:', email);
                } else {
                  // Try alternative email selectors
                  const emailSelectors = [
                    '.pv-contact-info__ci-container',
                    '.t-14.t-black.t-normal',
                    '.pv-contact-info__contact-item'
                  ];
                  
                  for (const selector of emailSelectors) {
                    const emailText = item.querySelector(selector);
                    if (emailText) {
                      email = emailText.textContent.trim();
                      console.log(`Extracted email using selector ${selector}:`, email);
                      break;
                    }
                  }
                }
              }
              
              // Phone extraction
              if (header.includes('phone')) {
                console.log('Found phone section:', item.outerHTML);
                const phoneSelectors = [
                  '.pv-contact-info__ci-container',
                  '.t-14.t-black.t-normal',
                  '.pv-contact-info__contact-item'
                ];
                
                for (const selector of phoneSelectors) {
                  const phoneElement = item.querySelector(selector);
                  if (phoneElement) {
                    phone = phoneElement.textContent.trim();
                    console.log(`Extracted phone using selector ${selector}:`, phone);
                    break;
                  }
                }
              }
              
              // Website extraction
              if (header.includes('website') || header.includes('url')) {
                console.log('Found website section:', item.outerHTML);
                const websiteLink = item.querySelector('a[href^="http"]');
                if (websiteLink) {
                  website = websiteLink.href.trim();
                  console.log('Extracted website from link:', website);
                } else {
                  // Try alternative website selectors
                  const websiteSelectors = [
                    '.pv-contact-info__ci-container',
                    '.t-14.t-black.t-normal',
                    '.pv-contact-info__contact-item'
                  ];
                  
                  for (const selector of websiteSelectors) {
                    const websiteText = item.querySelector(selector);
                    if (websiteText) {
                      website = websiteText.textContent.trim();
                      console.log(`Extracted website using selector ${selector}:`, website);
                      break;
                    }
                  }
                }
              }
            }
          }

          // Verify we have contact info
          console.log('Final extracted contact info:', {
            email: email || 'Not found',
            phone: phone || 'Not found',
            website: website || 'Not found'
          });

          // After extracting all data, close the overlay
          console.log('Contact info extraction complete, closing overlay');
          setTimeout(closeContactInfoOverlay, 500); // Small delay to ensure data is sent

          // Return the merged data
          const mergedData = {
            ...cachedProfileData,
            name: name !== 'Unknown Name' ? name : cachedProfileData?.name,
            email: email || '',
            phone: phone || '',
            website: website || ''
          };
          console.log('Final merged data:', mergedData);
          return mergedData;
        } else {
          console.log('No contact items found after waiting');
          // If we can't find contact items, close the overlay and return cached data
          setTimeout(closeContactInfoOverlay, 500);
          return {
            ...cachedProfileData,
            email: '',
            phone: '',
            website: ''
          };
        }
      });
    } else {
      // On profile page
      console.log('On profile page');
      
      // Scrape basic profile data with multiple selectors for name
      const nameSelectors = [
        '.pv-top-card h1',
        '.text-heading-xlarge',
        '[aria-hidden="true"][dir="ltr"]',
        '.pv-text-details__left-panel h1',
        '.artdeco-entity-lockup__title',
        '.pv-contact-info__profile-title'
      ];
      
      let nameElement = null;
      for (const selector of nameSelectors) {
        nameElement = document.querySelector(selector);
        if (nameElement) {
          console.log('Found name with selector:', selector);
          break;
        }
      }
      
      name = nameElement ? nameElement.textContent.trim() : 'Unknown Name';
      console.log('Name element:', nameElement ? nameElement.outerHTML : 'Not found');

      // First try to get company from headline
      const headlineElement = document.querySelector('.text-body-medium.break-words');
      if (headlineElement) {
        const headlineText = headlineElement.textContent.trim();
        console.log('Headline text:', headlineText);
        
        // Try multiple patterns to extract company
        let headlineMatch = headlineText.match(/(?:at|@)\s+([^|]+?)(?:\s*[|,]|\s*$)/i);  // @ Company | or @ Company, or @ Company
        if (!headlineMatch) {
          headlineMatch = headlineText.match(/(?:at|@)\s+([^,]+?)(?:\s*[|,]|\s*$)/i); // at Company | or at Company, or at Company
        }
        if (!headlineMatch) {
          headlineMatch = headlineText.match(/(?:at|@)\s+([^\n]+?)(?:\s*$)/i);          // @ Company at end
        }
        
        if (headlineMatch) {
          company = headlineMatch[1].trim();
          console.log('Extracted company from headline:', company);
        }
      }

      const positionElement = document.querySelector('.pv-text-details__left-panel .text-body-medium, .pv-top-card--list li+li, .pv-text-details__title');
      position = positionElement ? positionElement.textContent.trim() : '';
      console.log('Position element:', positionElement ? positionElement.outerHTML : 'Not found');

      // If no company found in headline, try Experience section
      if (!company) {
        // Try to load full Experience section
        tryLoadFullExperience();

        // Scrape Experience section
        const experienceItems = document.querySelectorAll('.pvs-list li span.t-14.t-normal, .pvs-list li span.t-14.t-black.t-normal, .pvs-list li span.t-14.t-black');
        console.log('Experience items found:', experienceItems.length);
        companies = Array.from(experienceItems)
          .map(el => {
            const rawText = el.textContent.trim();
            const parentLi = el.closest('.pvs-list li');
            const prevBold = parentLi?.querySelector('.t-bold, .t-16.t-black.t-bold'); // Position title
            const parentLink = el.closest('a');
            const href = parentLink ? parentLink.href : '';
            console.log(`Raw company text: ${rawText}, Has position title: ${!!prevBold}, Parent href: ${href}, Parent LI HTML: ${parentLi ? parentLi.outerHTML : 'Not found'}`);
            // Include if it follows a position title or has a company link
            if (prevBold || href.includes('/company/')) {
              // Clean text (remove " · Self-employed", " · On-site", etc.)
              const cleanText = rawText.replace(/ · .*$/, '').trim();
              return cleanText;
            }
            return null;
          })
          .filter(c => c && c !== '' && c !== 'Company Name') // Minimal filtering
          .filter((c, i, arr) => arr.indexOf(c) === i); // Remove duplicates
        console.log('Cleaned companies from Experience:', companies);
        company = companies[0] || ''; // Default to first company
      }

      // Capture LinkedIn URL
      linkedin_url = window.location.href.split('?')[0];
      console.log('Extracted LinkedIn URL from profile:', linkedin_url);

      // Cache profile data
      const basicData = { name, position, company, companies, email, phone, website, linkedin_url };
      console.log('Cached basic profile data:', basicData);
      cachedProfileData = basicData;
      return basicData;
    }
  } catch (error) {
    console.error('Error scraping profile:', error);
    return null;
  }
}

// Function to navigate to contact info overlay
function navigateToContactInfo() {
  const profilePath = window.location.pathname.match(/^\/in\/[^/]+/);
  if (profilePath) {
    const overlayUrl = `${profilePath[0]}/overlay/contact-info/`;
    console.log('Navigating to overlay:', overlayUrl);
    window.location.href = overlayUrl;
  } else {
    console.log('Could not determine profile path for overlay navigation');
  }
}

// Add this function after the navigateToContactInfo function
function closeContactInfoOverlay() {
  // Try different methods to close the overlay
  const closeButton = document.querySelector('button[aria-label="Dismiss"], .artdeco-modal__dismiss, .artdeco-button--circle');
  if (closeButton) {
    console.log('Found close button, clicking it');
    closeButton.click();
  } else {
    // If no close button found, try to go back
    console.log('No close button found, trying to go back');
    window.history.back();
  }
}

// Message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Message received in content.js:', request);
  if (request.action === 'ping') {
    console.log('Ping received, sending pong');
    sendResponse({ pong: true });
    return true;
  }
  if (request.action === 'scrape') {
    try {
      const data = scrapeLinkedInProfile();
      if (data instanceof Promise) {
        data.then(result => {
          console.log('Sending profile data after contact info:', result);
          sendResponse(result);
        });
      } else if (data) {
        console.log('Sending basic profile data:', data);
        sendResponse(data);
      } else {
        console.log('No data available');
        sendResponse(null);
      }
    } catch (error) {
      console.error('Error in scrape handler:', error);
      sendResponse(null);
    }
    return true; // Keep channel open
  }
  if (request.action === 'navigateToContactInfo') {
    navigateToContactInfo();
    sendResponse({ success: true });
  }
  return true; // Keep channel open
});

console.log('Message listener set up');

// Function to make an element draggable
function makeDraggable(element) {
  let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
  
  element.querySelector('.draggable').onmousedown = dragMouseDown;

  function dragMouseDown(e) {
    e.preventDefault();
    // get the mouse cursor position at startup
    pos3 = e.clientX;
    pos4 = e.clientY;
    document.onmouseup = closeDragElement;
    // call a function whenever the cursor moves
    document.onmousemove = elementDrag;
  }

  function elementDrag(e) {
    e.preventDefault();
    // calculate the new cursor position
    pos1 = pos3 - e.clientX;
    pos2 = pos4 - e.clientY;
    pos3 = e.clientX;
    pos4 = e.clientY;
    // set the element's new position
    element.style.top = (element.offsetTop - pos2) + "px";
    element.style.left = (element.offsetLeft - pos1) + "px";
  }

  function closeDragElement() {
    // stop moving when mouse button is released
    document.onmouseup = null;
    document.onmousemove = null;
  }
}

// Function to make an element resizable
function makeResizable(element) {
  const handle = element.querySelector('.resize-handle');
  let startX, startY, startWidth, startHeight;

  handle.addEventListener('mousedown', initResize);

  function initResize(e) {
    startX = e.clientX;
    startY = e.clientY;
    startWidth = parseInt(document.defaultView.getComputedStyle(element).width, 10);
    startHeight = parseInt(document.defaultView.getComputedStyle(element).height, 10);
    document.documentElement.addEventListener('mousemove', resize);
    document.documentElement.addEventListener('mouseup', stopResize);
  }

  function resize(e) {
    element.style.width = (startWidth + e.clientX - startX) + 'px';
    element.style.height = (startHeight + e.clientY - startY) + 'px';
  }

  function stopResize() {
    document.documentElement.removeEventListener('mousemove', resize);
    document.documentElement.removeEventListener('mouseup', stopResize);
  }
}

// Function to create a positioned element
function createPositionedElement(content, position = 'position-top-right') {
  const element = document.createElement('div');
  element.className = `linkedin-profile-element ${position}`;
  
  const draggableHeader = document.createElement('div');
  draggableHeader.className = 'draggable';
  draggableHeader.innerHTML = `
    <div class="close-button">×</div>
    <div class="resize-handle bottom-right"></div>
  `;
  
  const contentDiv = document.createElement('div');
  contentDiv.innerHTML = content;
  
  element.appendChild(draggableHeader);
  element.appendChild(contentDiv);
  
  document.body.appendChild(element);
  
  // Make the element draggable and resizable
  makeDraggable(element);
  makeResizable(element);
  
  // Add close button functionality
  element.querySelector('.close-button').addEventListener('click', () => {
    element.remove();
  });
  
  return element;
}

// Example usage:
// createPositionedElement('Your content here', 'position-top-right');