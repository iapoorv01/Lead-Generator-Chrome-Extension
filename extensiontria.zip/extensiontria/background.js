// HubSpot API endpoint and key
const HUBSPOT_API_KEY = 'pat-na2-dc03e3a4-31fb-472e-a1f5-64871f5a709c';
const HUBSPOT_CONTACTS_URL = 'https://api.hubapi.com/crm/v3/objects/contacts';
const HUBSPOT_PROPERTIES_URL = 'https://api.hubapi.com/crm/v3/properties/contacts';
const HUBSPOT_SEARCH_URL = 'https://api.hubapi.com/crm/v3/objects/contacts/search';

let currentTabId = null;

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    currentTabId = tabId;
    if (tab.url.match(/^https?:\/\/(www\.)?linkedin\.com\/in\/[^/?#]+/)) {
      chrome.action.openPopup();
    }
  }
});

async function ensurePropertyExists(name, label, type, fieldType, options = []) {
  try {
    const response = await fetch(`${HUBSPOT_PROPERTIES_URL}/${name}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${HUBSPOT_API_KEY}`
      }
    });
    if (response.ok) {
      console.log(`Property '${name}' already exists`);
      return true;
    }

    const propertyData = {
      name,
      label,
      type,
      fieldType,
      groupName: 'contactinformation'
    };
    if (options.length > 0) {
      propertyData.options = options.map(opt => ({ label: opt, value: opt.toLowerCase().replace(/\s+/g, '_') }));
    }

    const createResponse = await fetch(HUBSPOT_PROPERTIES_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${HUBSPOT_API_KEY}`
      },
      body: JSON.stringify(propertyData)
    });
    const createData = await createResponse.json();
    if (createData.name) {
      console.log(`Property '${name}' created successfully`);
      return true;
    } else {
      console.error(`Failed to create property '${name}':`, createData.message);
      return false;
    }
  } catch (error) {
    console.error(`Error ensuring property '${name}':`, error);
    return false;
  }
}

function isValidUrl(url) {
  if (!url) return false;
  try {
    new URL(url);
    return url.startsWith('https://www.linkedin.com/in/') || url.startsWith('https://linkedin.com/in/');
  } catch {
    return false;
  }
}

function mapLeadStatus(value) {
  const mapping = {
    'New': 'NEW',
    'Open': 'OPEN',
    'In Progress': 'IN_PROGRESS',
    'Qualified': 'OPEN_DEAL'
  };
  return mapping[value] || null;
}

function mapPersonaType(value) {
  const mapping = {
    'Decision Maker': 'decision_maker',
    'Influencer': 'influencer',
    'End User': 'end_user'
  };
  return mapping[value] || null;
}

async function findContact(profileData) {
  const filters = [];
  if (profileData.email) {
    filters.push({ propertyName: 'email', operator: 'EQ', value: profileData.email });
  }
  if (profileData.linkedin_url && isValidUrl(profileData.linkedin_url)) {
    filters.push({ propertyName: 'hs_linkedin_url', operator: 'EQ', value: profileData.linkedin_url });
  }
  if (profileData.name && !profileData.email && !profileData.linkedin_url) {
    const [firstname, ...lastnameArr] = profileData.name.split(' ');
    if (firstname) {
      filters.push({ propertyName: 'firstname', operator: 'EQ', value: firstname });
    }
    if (lastnameArr.length > 0) {
      filters.push({ propertyName: 'lastname', operator: 'EQ', value: lastnameArr.join(' ') });
    }
  }

  if (filters.length === 0) {
    return null;
  }

  const searchPayload = {
    filterGroups: [{ filters }],
    properties: ['email', 'hs_linkedin_url', 'firstname', 'lastname']
  };

  const response = await fetch(HUBSPOT_SEARCH_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${HUBSPOT_API_KEY}`
    },
    body: JSON.stringify(searchPayload)
  });
  const data = await response.json();
  return data.results && data.results.length > 0 ? data.results[0] : null;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkLeadExists') {
    const { data } = request;
    
    if (!data.name && !data.email && !data.linkedin_url) {
      sendResponse({ exists: false, error: 'No valid search criteria provided' });
      return true;
    }

    findContact(data).then(contact => {
      sendResponse({ 
        exists: !!contact,
        contact: contact
      });
    }).catch(error => {
      console.error('Error checking lead existence:', error);
      sendResponse({ exists: false, error: error.message });
    });

    return true;
  }

  if (request.action === 'sendToHubSpot') {
    const { name, position, company, email, phone, website, linkedin_url, lead_status, persona_type } = request.data;

    Promise.all([
      ensurePropertyExists('website', 'Website', 'string', 'text')
    ]).then(async (results) => {
      if (!results.every(r => r)) {
        sendResponse({ success: false, message: 'Error: Failed to create required property' });
        return;
      }

      const validatedLinkedinUrl = isValidUrl(linkedin_url) ? linkedin_url : null;
      const contactData = {
        properties: {
          firstname: name.split(' ')[0] || '',
          lastname: name.split(' ').slice(1).join(' ') || '',
          jobtitle: position || null,
          company: company || null,
          email: email || null,
          phone: phone || null,
          website: website || null,
          hs_linkedin_url: validatedLinkedinUrl || null,
          hs_lead_status: mapLeadStatus(lead_status) || null,
          hs_persona: mapPersonaType(persona_type) || null
        }
      };

      try {
        const contact = await findContact(request.data);
        if (contact) {
          sendResponse({ success: true, message: `Contact already exists in HubSpot (ID: ${contact.id})` });
          return;
        }

        const createResponse = await fetch(HUBSPOT_CONTACTS_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${HUBSPOT_API_KEY}`
          },
          body: JSON.stringify(contactData)
        });
        const createData = await createResponse.json();

        if (createData.id) {
          sendResponse({ success: true, message: 'Contact added to HubSpot' });
        } else {
          sendResponse({ success: false, message: 'Failed to add contact: ' + (createData.message || 'Unknown error') });
        }
      } catch (error) {
        sendResponse({ success: false, message: 'Error: ' + error.message });
      }
    });

    return true;
  }

  if (request.action === 'createHubSpotProperty') {
    const { name, type } = request;
    const propertyData = {
      name: name.replace(/\s+/g, '_').toLowerCase(),
      label: name,
      type: type,
      fieldType: type === 'bool' ? 'booleancheckbox' : type === 'date' ? 'date' : 'text',
      groupName: 'contactinformation'
    };

    fetch(HUBSPOT_PROPERTIES_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${HUBSPOT_API_KEY}`
      },
      body: JSON.stringify(propertyData)
    })
      .then(response => response.json())
      .then(data => {
        if (data.name) {
          sendResponse({ success: true, message: `Property '${data.label}' created successfully` });
        } else {
          sendResponse({ success: false, message: 'Error: Failed to create property: ' + (data.message || 'Unknown error') });
        }
      })
      .catch(error => {
        sendResponse({ success: false, message: 'Error: ' + error.message });
      });

    return true;
  }

  if (request.action === 'searchHubSpotContacts') {
    const { query } = request;

    if (!query) {
      sendResponse({ success: false, message: 'Search query is required' });
      return true;
    }

    const searchPayload = {
      filterGroups: [
        {
          filters: [
            {
              propertyName: 'firstname',
              operator: 'CONTAINS_TOKEN',
              value: query
            }
          ]
        },
        {
          filters: [
            {
              propertyName: 'lastname',
              operator: 'CONTAINS_TOKEN',
              value: query
            }
          ]
        },
        {
          filters: [
            {
              propertyName: 'email',
              operator: 'CONTAINS_TOKEN',
              value: query
            }
          ]
        }
      ],
      properties: ['firstname', 'lastname', 'email'],
      sorts: [{ propertyName: 'firstname', direction: 'ASCENDING' }],
      limit: 20
    };

    fetch(HUBSPOT_SEARCH_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${HUBSPOT_API_KEY}`
      },
      body: JSON.stringify(searchPayload)
    })
    .then(response => response.json())
    .then(data => {
      sendResponse({
        success: true,
        contacts: data.results || []
      });
    })
    .catch(error => {
      sendResponse({ success: false, message: 'Error: ' + error.message });
    });

    return true;
  }

  if (request.action === 'updateHubSpotContact') {
    const { contactId, data } = request;

    if (!contactId) {
      sendResponse({ success: false, message: 'Contact ID is required' });
      return true;
    }

    Promise.all([
      ensurePropertyExists('website', 'Website', 'string', 'text')
    ]).then(async (results) => {
      if (!results.every(r => r)) {
        sendResponse({ success: false, message: 'Error: Failed to ensure required property' });
        return;
      }

      const validatedLinkedinUrl = isValidUrl(data.linkedin_url) ? data.linkedin_url : null;
      const contactData = {
        properties: {}
      };

      // Only include non-null/undefined values
      const fields = {
        firstname: data.firstname,
        lastname: data.lastname,
        jobtitle: data.position,
        company: data.company,
        email: data.email,
        phone: data.phone,
        website: data.website,
        hs_linkedin_url: validatedLinkedinUrl,
        hs_lead_status: mapLeadStatus(data.lead_status),
        hs_persona: mapPersonaType(data.persona_type)
      };

      Object.entries(fields).forEach(([key, value]) => {
        if (value !== null && value !== undefined && value !== '') {
          contactData.properties[key] = value;
        }
      });

      try {
        const updateResponse = await fetch(`${HUBSPOT_CONTACTS_URL}/${contactId}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${HUBSPOT_API_KEY}`
          },
          body: JSON.stringify(contactData)
        });
        const updateData = await updateResponse.json();

        if (updateResponse.ok) {
          sendResponse({ success: true, message: `Contact updated successfully (ID: ${contactId})` });
        } else {
          sendResponse({ success: false, message: 'Failed to update contact: ' + (updateData.message || 'Unknown error') });
        }
      } catch (error) {
        sendResponse({ success: false, message: 'Error: ' + error.message });
      }
    });

    return true;
  }

  if (request.action === 'getHubSpotProperties') {
    fetch(HUBSPOT_PROPERTIES_URL, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${HUBSPOT_API_KEY}`
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.results) {
        sendResponse({ 
          success: true, 
          properties: data.results.map(prop => ({
            name: prop.name,
            label: prop.label,
            type: prop.type
          }))
        });
      } else {
        sendResponse({ success: false, message: 'Failed to fetch properties' });
      }
    })
    .catch(error => {
      sendResponse({ success: false, message: 'Error: ' + error.message });
    });

    return true;
  }

  if (request.action === 'addPropertyValue') {
    const { propertyName, propertyValue, profileData } = request;

    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];

      try {
        const contact = await findContact(profileData);
        if (!contact) {
          sendResponse({ success: false, message: 'Error: Contact not found in HubSpot' });
          return;
        }

        const updateData = {
          properties: {
            [propertyName]: propertyValue
          }
        };

        const updateResponse = await fetch(`${HUBSPOT_CONTACTS_URL}/${contact.id}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${HUBSPOT_API_KEY}`
          },
          body: JSON.stringify(updateData)
        });

        if (updateResponse.ok) {
          sendResponse({ success: true, message: 'Property value added successfully' });
        } else {
          const errorData = await updateResponse.json();
          sendResponse({ success: false, message: 'Failed to add property value: ' + (errorData.message || 'Unknown error') });
        }
      } catch (error) {
        sendResponse({ success: false, message: 'Error: ' + error.message });
      }
    });

    return true;
  }

  if (request.action === 'deletePropertyValue') {
    const { propertyName, profileData } = request;

    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];

      try {
        const contact = await findContact(profileData);
        if (!contact) {
          sendResponse({ success: false, message: 'Error: Contact not found in HubSpot' });
          return;
        }

        const updateData = {
          properties: {
            [propertyName]: null
          }
        };

        const updateResponse = await fetch(`${HUBSPOT_CONTACTS_URL}/${contact.id}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${HUBSPOT_API_KEY}`
          },
          body: JSON.stringify(updateData)
        });

        if (updateResponse.ok) {
          sendResponse({ success: true, message: 'Property value deleted successfully' });
        } else {
          const errorData = await updateResponse.json();
          sendResponse({ success: false, message: 'Failed to delete property value: ' + (errorData.message || 'Unknown error') });
        }
      } catch (error) {
        sendResponse({ success: false, message: 'Error: ' + error.message });
      }
    });

    return true;
  }

  if (request.action === 'pageTypeChanged') {
    if (request.isProfilePage) {
      chrome.action.openPopup();
    }
  }

  if (request.action === 'getPopupData') {
    sendResponse({
      leadStatus: document.getElementById('lead-status')?.value,
      personaType: document.getElementById('persona-type')?.value
    });
  }
});