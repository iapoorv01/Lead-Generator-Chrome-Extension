document.getElementById('extract').addEventListener('click', () => {
  const status = document.getElementById('status');
  status.textContent = 'Checking...';

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.url) {
      status.textContent = 'Error: No active tab found';
      return;
    }

    if (!tab.url.match(/^https?:\/\/(www\.)?linkedin\.com\/in\/[^/?#]+/)) {
      status.textContent = 'Error: Please open a LinkedIn profile page';
      return;
    }

    let attempts = 0;
    const maxAttempts = 3;
    const retryDelay = 1000;

    function trySendMessage() {
      attempts++;
      chrome.tabs.sendMessage(tab.id, { action: 'scrape' }, (profileData) => {
        if (chrome.runtime.lastError) {
          if (attempts < maxAttempts) {
            status.textContent = `Retrying... (${attempts}/${maxAttempts})`;
            setTimeout(trySendMessage, retryDelay);
            return;
          }
          status.textContent = 'Error: Content script not loaded. Please refresh the page.';
          return;
        }

        if (!profileData) {
          status.textContent = 'Error: Could not extract data';
          return;
        }

        window.currentProfileData = profileData;

        const companySelect = document.getElementById('company-select');
        companySelect.innerHTML = '';
        if (profileData.companies && profileData.companies.length > 0) {
          profileData.companies.forEach((comp, index) => {
            const option = document.createElement('option');
            option.value = comp;
            option.textContent = comp || 'Unknown Company';
            if (index === 0) option.selected = true;
            companySelect.appendChild(option);
          });
        } else {
          const option = document.createElement('option');
          option.value = profileData.company || '';
          option.textContent = profileData.company || 'No company found';
          companySelect.appendChild(option);
        }

        const selectedCompany = companySelect.value;
        const leadStatus = document.getElementById('lead-status').value;
        const personaType = document.getElementById('persona-type').value;

        const hubspotData = {
          ...profileData,
          company: selectedCompany,
          lead_status: leadStatus || null,
          persona_type: personaType || null
        };

        if (!profileData.email && !profileData.phone) {
          chrome.tabs.sendMessage(tab.id, { action: 'navigateToContactInfo' }, (response) => {
            if (response && response.success) {
              status.textContent = 'Navigating to contact info...';
              let retryCount = 0;
              const maxRetries = 5;
              const retryInterval = 1000;

              function trySendToHubSpot() {
                chrome.tabs.sendMessage(tab.id, { action: 'scrape' }, (newProfileData) => {
                  if (chrome.runtime.lastError) {
                    status.textContent = 'Error: Content script not responding';
                    return;
                  }

                  if (!newProfileData) {
                    status.textContent = 'Error: Could not extract contact info';
                    return;
                  }

                  const updatedHubspotData = {
                    ...hubspotData,
                    email: newProfileData.email || '',
                    phone: newProfileData.phone || '',
                    website: newProfileData.website || ''
                  };

                  if (newProfileData.email || newProfileData.phone || retryCount >= maxRetries) {
                    chrome.runtime.sendMessage(
                      { action: 'sendToHubSpot', data: updatedHubspotData },
                      (response) => {
                        status.textContent = response ? response.message : 'Error: No response';
                      }
                    );
                  } else {
                    retryCount++;
                    status.textContent = `Waiting for contact info... (${retryCount}/${maxRetries})`;
                    setTimeout(trySendToHubSpot, retryInterval);
                  }
                });
              }

              setTimeout(trySendToHubSpot, 3000);
            } else {
              status.textContent = 'Error: Could not navigate to contact info';
            }
          });
        } else {
          chrome.runtime.sendMessage(
            { action: 'sendToHubSpot', data: hubspotData },
            (response) => {
              status.textContent = response ? response.message : 'Error: No response';
            }
          );
        }
      });
    }

    trySendMessage();
  });
});

// Property management functions
function createPropertyItem(name, value) {
  const div = document.createElement('div');
  div.className = 'property-item';
  div.innerHTML = `
    <span class="property-name">${name}</span>
    <span class="property-value">${value}</span>
    <div class="property-actions">
      <button class="property-edit" data-name="${name}">✎</button>
      <button class="property-delete" data-name="${name}">×</button>
    </div>
  `;
  return div;
}

function updatePropertyList(properties) {
  const propertyList = document.getElementById('property-list');
  propertyList.innerHTML = '';
  
  Object.entries(properties).forEach(([name, value]) => {
    if (value !== null && value !== undefined && value !== '') {
      const item = createPropertyItem(name, value);
      propertyList.appendChild(item);
    }
  });

  propertyList.querySelectorAll('.property-edit').forEach(button => {
    button.addEventListener('click', () => {
      const name = button.dataset.name;
      const value = properties[name];
      document.getElementById('property-select').value = name;
      document.getElementById('property-value').value = value;
    });
  });

  propertyList.querySelectorAll('.property-delete').forEach(button => {
    button.addEventListener('click', () => {
      const name = button.dataset.name;
      if (confirm(`Are you sure you want to delete the property "${name}"?`)) {
        const profileData = window.currentProfileData;
        if (!profileData) {
          document.getElementById('status').textContent = 'Error: No profile data available';
          return;
        }

        chrome.runtime.sendMessage(
          { 
            action: 'deletePropertyValue', 
            propertyName: name,
            profileData: profileData
          },
          (response) => {
            if (response && response.success) {
              delete properties[name];
              updatePropertyList(properties);
              document.getElementById('status').textContent = 'Property deleted successfully';
            } else {
              document.getElementById('status').textContent = 'Error: ' + (response ? response.message : 'Failed to delete property');
            }
          }
        );
      }
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const statusBadge = document.getElementById('lead-status-badge');
  const extractButton = document.getElementById('extract');
  const propertySelect = document.getElementById('property-select');

  statusBadge.style.display = 'block';
  statusBadge.textContent = 'Checking lead status...';
  statusBadge.className = 'lead-status-badge lead-new';

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.url) {
      statusBadge.textContent = 'Error: No active tab found';
      return;
    }

    if (!tab.url.match(/^https?:\/\/(www\.)?linkedin\.com\/in\/[^/?#]+/)) {
      statusBadge.textContent = 'Error: Please open a LinkedIn profile page';
      return;
    }

    chrome.tabs.sendMessage(tab.id, { action: 'scrape' }, (profileData) => {
      if (chrome.runtime.lastError || !profileData) {
        statusBadge.textContent = 'Error: Could not check lead status';
        return;
      }

      window.currentProfileData = profileData;

      chrome.runtime.sendMessage(
        { action: 'checkLeadExists', data: profileData },
        (response) => {
          if (response && response.exists) {
            const contact = response.contact;
            const name = contact ? `${contact.properties.firstname || ''} ${contact.properties.lastname || ''}`.trim() : '';
            statusBadge.textContent = `✓ Lead exists in HubSpot${name ? ` (${name})` : ''}`;
            statusBadge.className = 'lead-status-badge lead-exists';
            extractButton.disabled = true;
            window.currentProperties = contact.properties;
            updatePropertyList(contact.properties);
          } else {
            statusBadge.textContent = 'New lead - Ready to add to HubSpot';
            statusBadge.className = 'lead-status-badge lead-new';
            extractButton.disabled = false;
            window.currentProperties = {};
            updatePropertyList({});
          }
        }
      );
    });
  });

  chrome.runtime.sendMessage(
    { action: 'getHubSpotProperties' },
    (response) => {
      if (response && response.success && response.properties) {
        propertySelect.innerHTML = '<option value="">Select a property</option>';
        response.properties.forEach(prop => {
          const option = document.createElement('option');
          option.value = prop.name;
          option.textContent = prop.label;
          propertySelect.appendChild(option);
        });
      }
    }
  );

  document.getElementById('add-property-value').addEventListener('click', () => {
    const status = document.getElementById('status');
    const propertyName = document.getElementById('property-select').value;
    const propertyValue = document.getElementById('property-value').value.trim();

    if (!propertyName) {
      status.textContent = 'Please select a property';
      return;
    }

    if (!propertyValue) {
      status.textContent = 'Property value is required';
      return;
    }

    const profileData = window.currentProfileData;
    if (!profileData) {
      status.textContent = 'Error: No profile data available';
      return;
    }

    chrome.runtime.sendMessage(
      { 
        action: 'addPropertyValue', 
        propertyName: propertyName,
        propertyValue: propertyValue,
        profileData: profileData
      },
      (response) => {
        if (response && response.success) {
          window.currentProperties[propertyName] = propertyValue;
          updatePropertyList(window.currentProperties);
          document.getElementById('property-value').value = '';
          status.textContent = 'Property value added successfully';
        } else {
          status.textContent = 'Error: ' + (response ? response.message : 'Failed to add property');
        }
      }
    );
  });

  document.getElementById('create-property').addEventListener('click', () => {
    const status = document.getElementById('status');
    const propertyName = document.getElementById('property-name').value.trim();
    const propertyType = document.getElementById('property-type').value;

    if (!propertyName) {
      status.textContent = 'Error: Property name is required';
      return;
    }

    chrome.runtime.sendMessage(
      { action: 'createHubSpotProperty', name: propertyName, type: propertyType },
      (response) => {
        if (response && response.success) {
          status.textContent = response.message;
          document.getElementById('property-name').value = '';
          chrome.runtime.sendMessage(
            { action: 'getHubSpotProperties' },
            (propResponse) => {
              if (propResponse && propResponse.success && propResponse.properties) {
                const propertySelect = document.getElementById('property-select');
                propertySelect.innerHTML = '<option value="">Select a property</option>';
                propResponse.properties.forEach(prop => {
                  const option = document.createElement('option');
                  option.value = prop.name;
                  option.textContent = prop.label;
                  propertySelect.appendChild(option);
                });
              }
            }
          );
        } else {
          status.textContent = 'Error: ' + (response ? response.message : 'Failed to create property');
        }
      }
    );
  });
});

function debounce(func, wait) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

const searchInput = document.getElementById('contact-search');
const searchResults = document.getElementById('search-results');
const linkButton = document.getElementById('link-contact');
const status = document.getElementById('status');

const searchContacts = debounce(() => {
  const value = searchInput.value.trim();
  if (!value) {
    status.textContent = '';
    searchResults.innerHTML = '';
    searchResults.style.display = 'none';
    linkButton.disabled = true;
    return;
  }
  status.textContent = 'Searching contacts...';
  searchResults.innerHTML = '';
  searchResults.style.display = 'none';
  linkButton.disabled = true;

  chrome.runtime.sendMessage(
    { action: 'searchHubSpotContacts', query: value },
    (response) => {
      if (response && response.success && response.contacts) {
        if (response.contacts.length === 0) {
          status.textContent = 'No contacts found.';
          return;
        }
        searchResults.style.display = 'block';
        response.contacts.forEach((contact) => {
          const div = document.createElement('div');
          div.className = 'search-result';
          div.textContent = `${contact.properties.firstname || ''} ${contact.properties.lastname || ''} (${contact.properties.email || 'No email'})`;
          div.dataset.contactId = contact.id;
          div.addEventListener('click', () => {
            document.querySelectorAll('.search-result').forEach(el => el.classList.remove('selected'));
            div.classList.add('selected');
            linkButton.disabled = false;
            window.selectedContactId = contact.id;
          });
          searchResults.appendChild(div);
        });
        status.textContent = `Found ${response.contacts.length} contact(s)`;
      } else {
        status.textContent = 'Error: ' + (response ? response.message : 'No response');
      }
    }
  );
}, 400);

searchInput.addEventListener('input', searchContacts);

document.getElementById('link-contact').addEventListener('click', () => {
  const status = document.getElementById('status');
  const selectedContactId = window.selectedContactId;
  const profileData = window.currentProfileData;

  if (!selectedContactId || !profileData) {
    status.textContent = 'Error: No contact selected or profile data missing';
    return;
  }

  status.textContent = 'Processing...';

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    chrome.tabs.sendMessage(tab.id, { action: 'navigateToContactInfo' }, (navResponse) => {
      if (!navResponse || !navResponse.success) {
        status.textContent = 'Error: Could not navigate to contact info';
        return;
      }

      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, { action: 'scrape' }, (scrapedData) => {
          if (!scrapedData) {
            status.textContent = 'Error: Could not scrape contact info';
            return;
          }

          const companySelect = document.getElementById('company-select');
          const selectedCompany = companySelect.value;
          const leadStatus = document.getElementById('lead-status').value;
          const personaType = document.getElementById('persona-type').value;

          const mergedData = {
            ...profileData,
            email: scrapedData.email || '',
            phone: scrapedData.phone || '',
            website: scrapedData.website || '',
            company: selectedCompany || profileData.company || '',
            lead_status: leadStatus || null,
            persona_type: personaType || null
          };

          let name = mergedData.name || 'Unknown Name';
          let [firstname, ...lastnameArr] = name.split(' ');
          let lastname = lastnameArr.join(' ');

          const filteredData = {};
          Object.entries(mergedData).forEach(([key, value]) => {
            if (value !== undefined && value !== null && value !== '') {
              filteredData[key] = value;
            }
          });

          filteredData.firstname = firstname || '';
          filteredData.lastname = lastname || '';

          chrome.runtime.sendMessage(
            { action: 'updateHubSpotContact', contactId: selectedContactId, data: filteredData },
            (response) => {
              if (response && response.success) {
                status.textContent = response.message;
                document.getElementById('contact-search').value = '';
                searchResults.innerHTML = '';
                searchResults.style.display = 'none';
                window.selectedContactId = null;
              } else {
                status.textContent = 'Error: ' + (response ? response.message : 'No response');
              }
            }
          );
        });
      }, 2000);
    });
  });
});